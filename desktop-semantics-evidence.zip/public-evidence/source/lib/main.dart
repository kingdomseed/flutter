import 'dart:async';
import 'dart:convert';
import 'dart:developer' show Timeline;
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';

import 'instrumented_repro.dart' as repro;
import 'native_metrics.dart';

const workload = String.fromEnvironment('WORKLOAD', defaultValue: 'repro');
const sourceLabel = String.fromEnvironment('SOURCE_LABEL');
const buildLabel = String.fromEnvironment('BUILD_LABEL');
const expectedRefresh = String.fromEnvironment('EXPECTED_REFRESH_HZ');
const resultPrefix = 'SEMANTICS_BENCHMARK_RESULT ';

void main() {
  final benchmark = Benchmark();
  runZonedGuarded(
    () {
      WidgetsFlutterBinding.ensureInitialized();
      repro.heldHandle = SemanticsBinding.instance.ensureSemantics();
      final previousError = FlutterError.onError;
      FlutterError.onError = (details) {
        benchmark.errors.add('${details.exception}\n${details.stack}');
        previousError?.call(details);
      };
      ui.PlatformDispatcher.instance.onError = (error, stack) {
        benchmark.errors.add('$error\n$stack');
        stderr.writeln('$error\n$stack');
        return true;
      };
      benchmark.prepare();
      runApp(
        MaterialApp(
          home: switch (workload) {
            'repro' => const repro.ReproPage(),
            'dense' => DensePage(benchmark: benchmark),
            _ => throw ArgumentError.value(
              workload,
              'WORKLOAD',
              'repro or dense',
            ),
          },
        ),
      );
      benchmark.start();
    },
    (error, stack) {
      benchmark.errors.add('$error\n$stack');
      unawaited(benchmark.abort());
    },
  );
}

enum Phase { warmup, measuring, draining, done }

class Benchmark {
  Phase phase = Phase.warmup;
  final errors = <String>[];
  final transitions = <Map<String, Object>>[];
  final timings = <ui.FrameTiming>[];
  final memory = <Map<String, int>>[];
  NativeMetrics? native;
  Timer? rssTimer;
  Timer? phaseTimer;
  late double refreshHz;
  late int launchMicros;
  late int startMicros;
  late int endMicros;
  late int cpuStart;
  late int cpuEnd;
  late int cpuStartReadMicros;
  late int cpuEndReadMicros;
  late Map<String, Object> startState;
  late Map<String, Object> endState;
  int drivenFrames = 0;
  int denseBuildBatches = 0;
  int denseLabelChangeBatches = 0;
  int denseLabelAssignments = 0;
  int denseTickerFrames = 0;
  int denseLastBuiltTick = -1;
  int reproTickerStart = 0;
  int reproBannerStart = 0;
  int reproTickerEnd = 0;
  int reproBannerEnd = 0;
  bool initialDemand = false;
  int lastRasterMicros = 0;

  void prepare() {
    if (!kReleaseMode) throw StateError('A release build is required');
    refreshHz = double.parse(expectedRefresh);
    if (!refreshHz.isFinite ||
        refreshHz <= 0 ||
        sourceLabel.isEmpty ||
        buildLabel.isEmpty) {
      throw ArgumentError(
        'SOURCE_LABEL, BUILD_LABEL and positive EXPECTED_REFRESH_HZ are required',
      );
    }
    native = NativeMetrics();
    final dispatcher = ui.PlatformDispatcher.instance;
    initialDemand = dispatcher.semanticsEnabled;
    final previousDemandCallback = dispatcher.onSemanticsEnabledChanged;
    dispatcher.onSemanticsEnabledChanged = () {
      transitions.add({
        'monotonicMicros': Timeline.now,
        'phase': phase.name,
        'nativeDemand': dispatcher.semanticsEnabled,
      });
      previousDemandCallback?.call();
    };
    SchedulerBinding.instance.addTimingsCallback(onTimings);
    SchedulerBinding.instance.addPersistentFrameCallback((_) {
      if (phase == Phase.measuring) drivenFrames++;
    });
  }

  void start() {
    launchMicros = Timeline.now;
    phaseTimer = Timer(const Duration(seconds: 5), beginMeasurement);
  }

  void beginMeasurement() {
    startState = snapshot();
    reproTickerStart = repro.drivenFrames;
    reproBannerStart = repro.bannerToggles;
    final before = Timeline.now;
    cpuStart = native!.cpuNanoseconds;
    final after = Timeline.now;
    startMicros = (before + after) ~/ 2;
    cpuStartReadMicros = after - before;
    phase = Phase.measuring;
    sampleMemory();
    rssTimer = Timer.periodic(
      const Duration(milliseconds: 250),
      (_) => sampleMemory(),
    );
    phaseTimer = Timer(const Duration(seconds: 20), endMeasurement);
  }

  void sampleMemory() {
    final sampleTime = Timeline.now;
    final rss = ProcessInfo.currentRss;
    if (rss <= 0) throw StateError('Invalid RSS $rss');
    memory.add({
      'monotonicMicros': sampleTime,
      'rssBytes': rss,
      'physicalFootprintBytes': native!.footprintBytes,
    });
  }

  void endMeasurement() {
    rssTimer!.cancel();
    sampleMemory();
    final before = Timeline.now;
    cpuEnd = native!.cpuNanoseconds;
    final after = Timeline.now;
    endMicros = (before + after) ~/ 2;
    cpuEndReadMicros = after - before;
    phase = Phase.draining;
    reproTickerEnd = repro.drivenFrames;
    reproBannerEnd = repro.bannerToggles;
    endState = snapshot();
    // Release timings are batched for up to one second. CPU and RSS are closed.
    phaseTimer = Timer(
      const Duration(milliseconds: 1500),
      () => unawaited(finish()),
    );
  }

  void onTimings(List<ui.FrameTiming> batch) {
    if (phase == Phase.warmup || phase == Phase.done) return;
    for (final timing in batch) {
      lastRasterMicros = math.max(
        lastRasterMicros,
        timing.timestampInMicroseconds(ui.FramePhase.rasterFinish),
      );
      if (timing.timestampInMicroseconds(ui.FramePhase.buildStart) >=
          startMicros) {
        timings.add(timing);
      }
    }
  }

  Map<String, Object> snapshot() {
    var attached = 0;
    var denseAttached = 0;
    var denseVisibleUnmerged = 0;
    void visitNode(SemanticsNode node) {
      if (node.attached) {
        attached++;
        if (node.label.startsWith('Dense cell ')) {
          denseAttached++;
          if (!node.isMergedIntoParent && !node.isInvisible) {
            denseVisibleUnmerged++;
          }
        }
      }
      node.visitChildren((child) {
        visitNode(child);
        return true;
      });
    }

    void visitOwner(PipelineOwner owner) {
      final root = owner.semanticsOwner?.rootSemanticsNode;
      if (root != null) visitNode(root);
      owner.visitChildren(visitOwner);
    }

    visitOwner(RendererBinding.instance.rootPipelineOwner);
    return {
      'nativeDemand': ui.PlatformDispatcher.instance.semanticsEnabled,
      'frameworkSemantics': SemanticsBinding.instance.semanticsEnabled,
      'heldHandle': repro.heldHandle != null,
      'attachedNodes': attached,
      'denseAttachedNodes': denseAttached,
      'denseVisibleUnmergedNodes': denseVisibleUnmerged,
      'views': [
        for (final view in ui.PlatformDispatcher.instance.views)
          {
            'viewId': view.viewId,
            'displayId': view.display.id,
            'displayRefreshHz': view.display.refreshRate,
            'displayPhysicalWidth': view.display.size.width,
            'displayPhysicalHeight': view.display.size.height,
            'devicePixelRatio': view.devicePixelRatio,
            'physicalWidth': view.physicalSize.width,
            'physicalHeight': view.physicalSize.height,
            'logicalWidth': view.physicalSize.width / view.devicePixelRatio,
            'logicalHeight': view.physicalSize.height / view.devicePixelRatio,
          },
      ],
    };
  }

  Future<void> finish() async {
    if (phase == Phase.done) return;
    final drainEnd = Timeline.now;
    final completed = timings
        .where(
          (timing) =>
              timing.timestampInMicroseconds(ui.FramePhase.rasterFinish) <=
              endMicros,
        )
        .toList();
    final wall = (endMicros - startMicros) / 1e6;
    final cpu = (cpuEnd - cpuStart) / 1e9;
    final minimumFrames = (wall * refreshHz * 0.8).ceil();
    final completedTolerance = math.max(3, (completed.length * 0.02).ceil());
    final buildTolerance = math.max(3, (drivenFrames * 0.02).ceil());
    if ((wall - 20).abs() > 0.5) {
      errors.add('Measured wall outside 20s +/- 0.5s');
    }
    if (completed.length < minimumFrames || drivenFrames < minimumFrames) {
      errors.add('Too few completed or driven frames for 80% expected refresh');
    }
    if (initialDemand || transitions.isNotEmpty) {
      errors.add('Native demand active or changed during process');
    }
    for (final state in [startState, endState]) {
      if (state['nativeDemand'] != false ||
          state['frameworkSemantics'] != true ||
          state['heldHandle'] != true) {
        errors.add('Invalid semantics demand or handle state');
      }
      if ((state['attachedNodes'] as int) < (workload == 'dense' ? 1001 : 2)) {
        errors.add('Too few actual attached nodes');
      }
      if (workload == 'dense' && state['denseVisibleUnmergedNodes'] != 1000) {
        errors.add(
          'Dense tree does not contain 1000 visible unmerged producers',
        );
      }
    }
    if (lastRasterMicros < endMicros) {
      errors.add('Timing drain did not reach the measurement end');
    }
    if (completed.map((f) => f.frameNumber).toSet().length !=
        completed.length) {
      errors.add('Duplicate FrameTiming frame numbers');
    }
    final producerFrames = workload == 'dense'
        ? denseTickerFrames
        : reproTickerEnd - reproTickerStart;
    if ((producerFrames - drivenFrames).abs() > 1) {
      errors.add('Producer and driven frames differ beyond one boundary frame');
    }
    if (workload == 'dense' &&
        ((denseBuildBatches - drivenFrames).abs() > buildTolerance ||
            (denseLabelChangeBatches - denseBuildBatches).abs() > 1 ||
            denseLabelAssignments != denseBuildBatches * 1000)) {
      errors.add(
        'Dense build or label counters differ beyond protocol allowance',
      );
    }
    if ((drivenFrames - completed.length).abs() > completedTolerance) {
      errors.add(
        'Driven and completed frames differ beyond 2% or 3 boundary frames',
      );
    }
    if (workload == 'repro' && reproBannerEnd - reproBannerStart < 12) {
      errors.add('Too few reproduction banner toggles');
    }
    if (cpu <= 0 || memory.length < 78) {
      errors.add('Missing process CPU or memory samples');
    }
    final result = <String, Object?>{
      'schemaVersion': 1,
      'status': errors.isEmpty ? 'ok' : 'error',
      'sourceLabel': sourceLabel,
      'buildLabel': buildLabel,
      'workload': workload,
      'syntheticStress': workload == 'dense',
      'releaseMode': kReleaseMode,
      'pid': pid,
      'expectedRefreshHz': refreshHz,
      'acceptance': {
        'wallTargetSeconds': 20,
        'wallToleranceSeconds': 0.5,
        'minimumRefreshFraction': 0.8,
        'minimumFrames': minimumFrames,
        'minimumAttachedNodes': workload == 'dense' ? 1001 : 2,
        'producerBoundaryToleranceFrames': 1,
        'minimumMemorySamples': 78,
        'completedBoundaryToleranceFrames': completedTolerance,
        'denseBuildBoundaryToleranceFrames': buildTolerance,
        'workCountToleranceFraction': 0.02,
      },
      'warmupActualSeconds': (startMicros - launchMicros) / 1e6,
      'measurementActualSeconds': wall,
      'measurementStartMonotonicMicros': startMicros,
      'measurementEndMonotonicMicros': endMicros,
      'timingDrainActualSeconds': (drainEnd - endMicros) / 1e6,
      'cpuClock':
          'clock_gettime(CLOCK_PROCESS_CPUTIME_ID=12), all process threads',
      'cpuStartNanoseconds': cpuStart,
      'cpuEndNanoseconds': cpuEnd,
      'cpuBoundaryReadMicros': {
        'start': cpuStartReadMicros,
        'end': cpuEndReadMicros,
      },
      'cpuSeconds': cpu,
      'cpuPercentOneCore': cpu / wall * 100,
      'cpuMsPerCompletedFrame': completed.isEmpty
          ? null
          : cpu * 1000 / completed.length,
      'completedFrames': completed.length,
      'drivenFrames': drivenFrames,
      'completedFps': completed.length / wall,
      'producerTickerFrames': producerFrames,
      'denseBuildBatches': denseBuildBatches,
      'denseLabelChangeBatches': denseLabelChangeBatches,
      'denseLabelAssignments': denseLabelAssignments,
      'reproBannerToggles': workload == 'repro'
          ? reproBannerEnd - reproBannerStart
          : 0,
      'reproFullBannerCycles': workload == 'repro'
          ? (reproBannerEnd - reproBannerStart) ~/ 2
          : 0,
      'rssBytes': distribution(memory.map((s) => s['rssBytes']!)),
      'physicalFootprintBytes': distribution(
        memory.map((s) => s['physicalFootprintBytes']!),
      ),
      'memorySampleIntervalMs': 250,
      'memorySamples': memory,
      'processLifetimeMaxRssBytes': ProcessInfo.maxRss,
      'buildMicros': distribution(
        completed.map((f) => f.buildDuration.inMicroseconds),
      ),
      'rasterMicros': distribution(
        completed.map((f) => f.rasterDuration.inMicroseconds),
      ),
      'frameSamples': [
        for (final timing in completed)
          {
            'frameNumber': timing.frameNumber,
            'buildStartMicros': timing.timestampInMicroseconds(
              ui.FramePhase.buildStart,
            ),
            'rasterFinishMicros': timing.timestampInMicroseconds(
              ui.FramePhase.rasterFinish,
            ),
            'buildMicros': timing.buildDuration.inMicroseconds,
            'rasterMicros': timing.rasterDuration.inMicroseconds,
          },
      ],
      'timingWindow': {
        'rule': 'buildStart >= CPU-window start and rasterFinish <= CPU-window end; late batches drained 1.5s',
        'firstBuildStartMicros': completed.isEmpty
            ? null
            : completed.first.timestampInMicroseconds(ui.FramePhase.buildStart),
        'lastRasterFinishMicros': completed.isEmpty
            ? null
            : completed.last.timestampInMicroseconds(
                ui.FramePhase.rasterFinish,
              ),
        'lastDeliveredRasterFinishMicros': lastRasterMicros,
        'excludedEndOrDrainFrames': timings.length - completed.length,
      },
      'initialNativeDemand': initialDemand,
      'nativeDemandTransitions': transitions,
      'start': startState,
      'end': endState,
      'errors': errors,
      'errorCount': errors.length,
      'nativeCommitCount': null,
      'proofLimit': 'Dart producer and framework tree only; native commit counts require separate profiling. FrameTiming excludes platform AX work.',
    };
    await emit(result);
  }

  Future<void> abort() async {
    if (phase == Phase.done) return;
    await emit({
      'schemaVersion': 1,
      'status': 'error',
      'sourceLabel': sourceLabel,
      'buildLabel': buildLabel,
      'workload': workload,
      'errors': errors,
      'errorCount': errors.length,
    });
  }

  Future<void> emit(Map<String, Object?> result) async {
    phase = Phase.done;
    rssTimer?.cancel();
    phaseTimer?.cancel();
    native?.close();
    native = null;
    stdout.writeln('$resultPrefix${jsonEncode(result)}');
    await stdout.flush();
    await stderr.flush();
    exit(result['status'] == 'ok' ? 0 : 1);
  }
}

Map<String, num?> distribution(Iterable<int> values) {
  final sorted = values.toList()..sort();
  num? percentile(double fraction) =>
      sorted.isEmpty ? null : sorted[(fraction * (sorted.length - 1)).ceil()];
  return {
    'count': sorted.length,
    'min': sorted.isEmpty ? null : sorted.first,
    'max': sorted.isEmpty ? null : sorted.last,
    'p50': sorted.isEmpty
        ? null
        : sorted.length.isOdd
        ? sorted[sorted.length ~/ 2]
        : (sorted[sorted.length ~/ 2 - 1] + sorted[sorted.length ~/ 2]) / 2,
    'p95': percentile(0.95),
  };
}

class DensePage extends StatefulWidget {
  const DensePage({required this.benchmark, super.key});
  final Benchmark benchmark;

  @override
  State<DensePage> createState() => _DensePageState();
}

class _DensePageState extends State<DensePage>
    with SingleTickerProviderStateMixin {
  late final Ticker ticker;
  int frame = 0;

  @override
  void initState() {
    super.initState();
    ticker = createTicker((_) {
      if (widget.benchmark.phase == Phase.measuring) {
        widget.benchmark.denseTickerFrames++;
      }
      setState(() => frame++);
    })..start();
  }

  @override
  void dispose() {
    ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final benchmark = widget.benchmark;
    if (benchmark.phase == Phase.measuring) {
      benchmark.denseBuildBatches++;
      if (benchmark.denseLastBuiltTick != frame) {
        benchmark.denseLabelChangeBatches++;
      }
    }
    benchmark.denseLastBuiltTick = frame;
    final rows = <Widget>[];
    for (var row = 0; row < 25; row++) {
      final cells = <Widget>[];
      for (var column = 0; column < 40; column++) {
        final label = 'Dense cell ${row * 40 + column} frame $frame';
        if (benchmark.phase == Phase.measuring) {
          benchmark.denseLabelAssignments++;
        }
        cells.add(
          Expanded(
            child: Semantics(
              container: true,
              explicitChildNodes: true,
              label: label,
              child: ColoredBox(
                color: (row + column).isEven
                    ? const Color(0xff245a81)
                    : const Color(0xff76b5c5),
                child: const SizedBox.expand(),
              ),
            ),
          ),
        );
      }
      rows.add(Expanded(child: Row(children: cells)));
    }
    return Column(children: rows);
  }
}
