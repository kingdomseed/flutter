import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/semantics.dart';

const holdSemantics = bool.fromEnvironment('HOLD_SEMANTICS');
SemanticsHandle? heldHandle;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  if (holdSemantics) heldHandle = SemanticsBinding.instance.ensureSemantics();
  debugPrint(
    'AX_REPRO start hold=$holdSemantics handle=${heldHandle != null} '
    'frameworkSemantics=${SemanticsBinding.instance.semanticsEnabled}',
  );
  runApp(const MaterialApp(home: ReproPage()));
}

class ReproPage extends StatefulWidget {
  const ReproPage({super.key});

  @override
  State<ReproPage> createState() => _ReproPageState();
}

class _ReproPageState extends State<ReproPage>
    with SingleTickerProviderStateMixin {
  final frames = ValueNotifier<int>(0);
  late final Ticker ticker;
  late final Timer bannerTimer;
  bool bannerVisible = false;

  @override
  void initState() {
    super.initState();
    ticker = createTicker((_) => frames.value++)..start();
    bannerTimer = Timer.periodic(const Duration(milliseconds: 1500), (_) {
      final messenger = ScaffoldMessenger.of(context);
      if (bannerVisible) {
        messenger.hideCurrentMaterialBanner();
      } else {
        messenger.showMaterialBanner(
          MaterialBanner(
            content: const Text('Accessibility update'),
            actions: [
              TextButton(
                onPressed: messenger.hideCurrentMaterialBanner,
                child: const Text('Dismiss'),
              ),
            ],
          ),
        );
      }
      bannerVisible = !bannerVisible;
      debugPrint(
        'AX_REPRO heartbeat frames=${frames.value} banner=$bannerVisible '
        'frameworkSemantics=${SemanticsBinding.instance.semanticsEnabled}',
      );
    });
  }

  @override
  void dispose() {
    ticker.dispose();
    bannerTimer.cancel();
    frames.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Flutter accessibility reproduction')),
    body: Center(
      child: ValueListenableBuilder<int>(
        valueListenable: frames,
        builder: (_, frame, _) => Text('Frame $frame'),
      ),
    ),
  );
}
