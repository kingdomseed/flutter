import 'dart:ffi';
import 'dart:io';

final class Timespec extends Struct {
  @Long()
  external int seconds;

  @Long()
  external int nanoseconds;
}

final class RusageInfoV0 extends Struct {
  @Array(16)
  external Array<Uint8> uuid;

  @Uint64()
  external int userTime;
  @Uint64()
  external int systemTime;
  @Uint64()
  external int packageIdleWakeups;
  @Uint64()
  external int interruptWakeups;
  @Uint64()
  external int pageins;
  @Uint64()
  external int wiredSize;
  @Uint64()
  external int residentSize;
  @Uint64()
  external int physicalFootprint;
  @Uint64()
  external int processStart;
  @Uint64()
  external int processExit;
}

class NativeMetrics {
  NativeMetrics() {
    if (!Platform.isMacOS) throw UnsupportedError('macOS only');
    time = calloc(1, sizeOf<Timespec>()).cast<Timespec>();
    usage = calloc(1, sizeOf<RusageInfoV0>()).cast<RusageInfoV0>();
    if (time == nullptr || usage == nullptr) {
      close();
      throw StateError('calloc failed');
    }
  }

  final library = DynamicLibrary.process();
  late final calloc = library
      .lookupFunction<
        Pointer<Void> Function(Size, Size),
        Pointer<Void> Function(int, int)
      >('calloc');
  late final free = library
      .lookupFunction<
        Void Function(Pointer<Void>),
        void Function(Pointer<Void>)
      >('free');
  late final clockGettime = library
      .lookupFunction<
        Int Function(Int, Pointer<Timespec>),
        int Function(int, Pointer<Timespec>)
      >('clock_gettime');
  late final pidRusage = DynamicLibrary.open('/usr/lib/libproc.dylib')
      .lookupFunction<
        Int Function(Int, Int, Pointer<Pointer<Void>>),
        int Function(int, int, Pointer<Pointer<Void>>)
      >('proc_pid_rusage');
  late final Pointer<Timespec> time;
  late final Pointer<RusageInfoV0> usage;

  int get cpuNanoseconds {
    if (clockGettime(12, time) != 0) {
      throw StateError('clock_gettime(CLOCK_PROCESS_CPUTIME_ID) failed');
    }
    return time.ref.seconds * 1000000000 + time.ref.nanoseconds;
  }

  int get footprintBytes {
    // libproc writes the structure into this buffer, despite rusage_info_t*.
    if (pidRusage(pid, 0, usage.cast<Pointer<Void>>()) != 0) {
      throw StateError('proc_pid_rusage(RUSAGE_INFO_V0) failed');
    }
    final bytes = usage.ref.physicalFootprint;
    if (bytes <= 0) throw StateError('Invalid physical footprint $bytes');
    return bytes;
  }

  void close() {
    free(time.cast<Void>());
    free(usage.cast<Void>());
  }
}
