import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

const resultPrefix = 'SEMANTICS_BENCHMARK_RESULT ';
const usage = '''Run with the provided SDK's dart executable.
run.dart --repro-a EXEC --repro-b EXEC --dense-a EXEC --dense-b EXEC
  --manifest FILE --output-dir NEW_DIRECTORY [--label NAME] [--timeout-seconds 40]

The manifest supplies archived identities and the expected build labels.
Each workload runs five trials per variant, with pairs AB, BA, AB, BA, AB.
''';

Future<void> main(List<String> arguments) async {
  if (arguments.length == 1 && arguments.single == '--help') {
    stdout.write(usage);
    return;
  }
  try {
    final options = Options.parse(arguments);
    final manifest = object(
      jsonDecode(await File(options.manifest).readAsString()),
      'manifest',
    );
    if (integer(manifest, 'schemaVersion') != 1)
      throw const FormatException('Manifest schemaVersion must be 1');
    final entries = array(manifest, 'entries');
    final binaries = <String, Binary>{};
    for (final workload in ['repro', 'dense']) {
      for (final variant in ['a', 'b']) {
        final key = '$workload-$variant';
        final path = File(options.paths[key]!).absolute.path;
        final matches = entries
            .map((e) => object(e, 'manifest entry'))
            .where((e) => e['workload'] == workload && e['variant'] == variant)
            .toList();
        if (matches.length != 1)
          throw FormatException('Expected one manifest entry for $key');
        binaries[key] = await Binary.read(
          matches.single,
          path,
          workload,
          variant,
        );
      }
      if (binaries['$workload-a']!.expectedRefreshHz !=
          binaries['$workload-b']!.expectedRefreshHz) {
        throw const FormatException(
          'Expected refresh must match between variants',
        );
      }
      if (binaries['$workload-a']!.sourceLabel ==
              binaries['$workload-b']!.sourceLabel ||
          (binaries['$workload-a']!.manifest['frameworkSha256'] as String)
                  .toLowerCase() ==
              (binaries['$workload-b']!.manifest['frameworkSha256'] as String)
                  .toLowerCase()) {
        throw const FormatException(
          'Variants must identify different engine sources and frameworks',
        );
      }
    }
    final output = Directory(options.outputDir);
    if (await output.exists())
      throw FileSystemException('Output directory must be new', output.path);
    await output.create(recursive: true);
    await File('${output.path}/manifest.json').writeAsString(pretty(manifest));
    final trials = <Trial>[];
    for (final workload in ['repro', 'dense']) {
      for (var pair = 0; pair < 5; pair++) {
        final order = pair.isEven ? ['a', 'b'] : ['b', 'a'];
        for (final variant in order) {
          final binary = binaries['$workload-$variant']!;
          final trial = await runTrial(
            binary,
            pair + 1,
            trials.length + 1,
            output,
            options,
          );
          trials.add(trial);
          stdout.writeln(
            '${trial.id} ${trial.failures.isEmpty ? 'OK' : 'ERROR'}',
          );
          // A process that survived both signals would contaminate every later trial.
          if (trial.unreaped)
            throw StateError('Could not reap ${trial.id}; no further launches');
        }
      }
    }
    final workloads = {
      for (final workload in ['repro', 'dense'])
        workload: summarize(
          trials.where((t) => t.binary.workload == workload).toList(),
        ),
    };
    final failed = workloads.values.any(
      (summary) => summary['status'] != 'complete',
    );
    final summary = <String, Object?>{
      'schemaVersion': 1,
      'label': options.label,
      'status': failed ? 'ERROR' : 'complete',
      'trialCount': trials.length,
      'failedTrials': trials.where((t) => t.failures.isNotEmpty).length,
      'axErrorLineCount': trials.fold<int>(0, (n, t) => n + t.axErrorLines),
      'diagnosticErrorLineCount': trials.fold<int>(
        0,
        (n, t) => n + t.diagnosticErrorLines,
      ),
      'missingResultTrials': trials
          .where((t) => t.resultRecordCount == 0)
          .length,
      'duplicateResultTrials': trials
          .where((t) => t.resultRecordCount > 1)
          .length,
      'errorPatterns': errorPatterns.map(
        (key, value) => MapEntry(key, value.pattern),
      ),
      'errorPatternSource': 'Every non-result stdout line and every stderr line; matching lines are counted per pattern and once in the AX union',
      'order': trials.map((t) => t.id).toList(),
      'workloads': workloads,
      'limiter': 'NOT_RUN; parent profiles separately. A numeric separation alone is not a performance verdict.',
      'scope': 'PR evidence only. Dense is synthetic. Native commits are not counted by Dart producer counters.',
    };
    await File('${output.path}/summary.json').writeAsString(pretty(summary));
    stdout.writeln('${output.absolute.path}/summary.json');
    exitCode = failed ? 1 : 0;
  } catch (error, stack) {
    stderr.writeln('ERROR $error\n$stack');
    exitCode = 1;
  }
}

class Options {
  Options(this.paths, this.manifest, this.outputDir, this.label, this.timeout);
  final Map<String, String> paths;
  final String manifest;
  final String outputDir;
  final String label;
  final Duration timeout;

  factory Options.parse(List<String> arguments) {
    const allowed = {
      'repro-a',
      'repro-b',
      'dense-a',
      'dense-b',
      'manifest',
      'output-dir',
      'label',
      'timeout-seconds',
    };
    final values = <String, String>{};
    for (var i = 0; i < arguments.length; i += 2) {
      if (!arguments[i].startsWith('--') || i + 1 >= arguments.length)
        throw const FormatException(usage);
      final name = arguments[i].substring(2);
      if (!allowed.contains(name) || values.containsKey(name))
        throw FormatException('Unknown or duplicate option $name\n$usage');
      values[name] = arguments[i + 1];
    }
    for (final name in [
      'repro-a',
      'repro-b',
      'dense-a',
      'dense-b',
      'manifest',
      'output-dir',
    ]) {
      if (values[name] == null || values[name]!.isEmpty)
        throw FormatException('Missing --$name\n$usage');
    }
    final seconds = int.parse(values['timeout-seconds'] ?? '40');
    if (seconds < 28)
      throw const FormatException(
        'Timeout must allow 5s warmup, 20s measurement and 1.5s timing drain',
      );
    return Options(
      {
        for (final key in ['repro-a', 'repro-b', 'dense-a', 'dense-b'])
          key: values[key]!,
      },
      values['manifest']!,
      values['output-dir']!,
      values['label'] ?? 'desktop-semantics',
      Duration(seconds: seconds),
    );
  }
}

class Binary {
  Binary(
    this.executable,
    this.workload,
    this.variant,
    this.sourceLabel,
    this.buildLabel,
    this.expectedRefreshHz,
    this.manifest,
  );
  final String executable;
  final String workload;
  final String variant;
  final String sourceLabel;
  final String buildLabel;
  final double expectedRefreshHz;
  final Map<String, dynamic> manifest;

  static Future<Binary> read(
    Map<String, dynamic> entry,
    String path,
    String workload,
    String variant,
  ) async {
    if (File(string(entry, 'executable')).absolute.path != path)
      throw const FormatException('Manifest executable differs from CLI path');
    final refresh = number(entry, 'expectedRefreshHz');
    if (refresh <= 0)
      throw const FormatException('Expected refresh must be positive');
    for (final (pathKey, hashKey) in [
      ('executable', 'executableSha256'),
      ('appArchive', 'appArchiveSha256'),
      ('frameworkBinary', 'frameworkSha256'),
    ]) {
      final file = File(string(entry, pathKey));
      if (!await file.exists())
        throw FileSystemException('Manifest file missing', file.path);
      final expected = string(entry, hashKey).toLowerCase();
      if (!RegExp(r'^[0-9a-f]{64}$').hasMatch(expected))
        throw FormatException('Invalid $hashKey');
      final hash = await Process.run('/usr/bin/shasum', [
        '-a',
        '256',
        file.absolute.path,
      ]);
      if (hash.exitCode != 0 ||
          (hash.stdout as String).split(RegExp(r'\s+')).first.toLowerCase() !=
              expected) {
        throw StateError('SHA256 verification failed for ${file.path}');
      }
    }
    return Binary(
      path,
      workload,
      variant,
      string(entry, 'sourceLabel'),
      string(entry, 'buildLabel'),
      refresh,
      entry,
    );
  }
}

class Trial {
  Trial(this.binary, this.id);
  final Binary binary;
  final String id;
  final failures = <String>[];
  int axErrorLines = 0;
  int diagnosticErrorLines = 0;
  int resultRecordCount = 0;
  bool unreaped = false;
  Measurement? measurement;
}

final errorPatterns = <String, RegExp>{
  'axTree': RegExp(r'\bAXTree\b', caseSensitive: false),
  'unserialize': RegExp(r'unserializ(?:e|ation|ing)', caseSensitive: false),
  'pending': RegExp(r'\bpending\b', caseSensitive: false),
  'fatal': RegExp(r'\bFATAL\b', caseSensitive: false),
  'errors': RegExp(
    r'\berrors?\b|\bexception\b|\bfailed\b|\bfailure\b|\bassertion\b',
    caseSensitive: false,
  ),
};

Future<Trial> runTrial(
  Binary binary,
  int pair,
  int sequence,
  Directory output,
  Options options,
) async {
  final trial = Trial(
    binary,
    '${sequence.toString().padLeft(2, '0')}-${binary.workload}-${binary.variant}-$pair',
  );
  final dir = Directory('${output.path}/${trial.id}');
  await dir.create();
  Map<String, Object?>? before;
  Map<String, Object?>? after;
  int? processExit;
  bool timedOut = false;
  String? launched;
  String? exited;
  final duration = Stopwatch();
  try {
    await Binary.read(
      binary.manifest,
      binary.executable,
      binary.workload,
      binary.variant,
    );
    before = await hostLoad();
    launched = DateTime.now().toUtc().toIso8601String();
    duration.start();
    final process = await Process.start(
      binary.executable,
      const [],
      runInShell: false,
    );
    final stdoutDone = process.stdout.pipe(
      File('${dir.path}/stdout.log').openWrite(),
    );
    final stderrDone = process.stderr.pipe(
      File('${dir.path}/stderr.log').openWrite(),
    );
    await Future<void>.delayed(const Duration(seconds: 1));
    final activation = await Process.run('cua-driver', [
      'bring_to_front',
      jsonEncode({'pid': process.pid, 'session': 'flutter-release-perf'}),
    ]);
    await File('${dir.path}/foreground.json')
        .writeAsString(activation.stdout as String);
    final foreground = object(
      jsonDecode(activation.stdout as String),
      'foreground result',
    );
    final windowEffect = foreground['exact_window_effect'];
    if (activation.exitCode != 0 ||
        foreground['activated'] != true ||
        foreground['pid'] != process.pid ||
        windowEffect is! Map ||
        windowEffect['verified'] != true ||
        windowEffect['target_visible_ordinary'] != true) {
      trial.failures.add(
        'Foreground activation did not verify the owned visible window',
      );
    }
    if (duration.elapsedMilliseconds >= 4500) {
      trial.failures.add('Foreground activation exceeded the warmup budget');
    }
    try {
      processExit = await process.exitCode.timeout(options.timeout);
    } on TimeoutException {
      timedOut = true;
      trial.failures.add('Process exceeded timeout and did not self-exit');
      process.kill(ProcessSignal.sigterm);
      try {
        processExit = await process.exitCode.timeout(
          const Duration(seconds: 2),
        );
      } on TimeoutException {
        process.kill(ProcessSignal.sigkill);
        try {
          processExit = await process.exitCode.timeout(
            const Duration(seconds: 2),
          );
        } on TimeoutException {
          trial.unreaped = true;
          trial.failures.add('Process did not exit after SIGKILL');
        }
      }
    }
    duration.stop();
    exited = DateTime.now().toUtc().toIso8601String();
    after = await hostLoad();
    if (!trial.unreaped) await Future.wait([stdoutDone, stderrDone]);
    if (processExit != 0)
      trial.failures.add('Nonzero or missing exit code $processExit');
    if (trial.unreaped) throw StateError('Unreaped child process');
    final stdoutText = await File('${dir.path}/stdout.log').readAsString();
    final stderrText = await File('${dir.path}/stderr.log').readAsString();
    final stdoutLines = const LineSplitter().convert(stdoutText);
    final stderrLines = const LineSplitter().convert(stderrText);
    final resultLines = stdoutLines
        .where((line) => line.startsWith(resultPrefix))
        .toList();
    trial.resultRecordCount = resultLines.length;
    final diagnosticLines = [
      ...stdoutLines.where((line) => !line.startsWith(resultPrefix)),
      ...stderrLines,
    ];
    final patternCounts = {
      for (final entry in errorPatterns.entries)
        entry.key: diagnosticLines.where(entry.value.hasMatch).length,
    };
    trial.diagnosticErrorLines = diagnosticLines
        .where(
          (line) =>
              errorPatterns.values.any((pattern) => pattern.hasMatch(line)),
        )
        .length;
    trial.axErrorLines = diagnosticLines
        .where(
          (line) =>
              errorPatterns['axTree']!.hasMatch(line) ||
              errorPatterns['unserialize']!.hasMatch(line) ||
              errorPatterns['pending']!.hasMatch(line),
        )
        .length;
    if (patternCounts.values.any((n) => n > 0))
      trial.failures.add('Diagnostic error patterns matched $patternCounts');
    await File('${dir.path}/diagnostics.json').writeAsString(
      pretty({
        'patterns': patternCounts,
        'axErrorLines': trial.axErrorLines,
        'diagnosticErrorLines': trial.diagnosticErrorLines,
        'resultRecordCount': trial.resultRecordCount,
        'matchingLines': [
          for (final line in diagnosticLines)
            if (errorPatterns.values.any((pattern) => pattern.hasMatch(line)))
              line,
        ],
      }),
    );
    if (resultLines.length != 1)
      throw FormatException(
        'Expected exactly one result, got ${resultLines.length}',
      );
    final result = object(
      jsonDecode(resultLines.single.substring(resultPrefix.length)),
      'result',
    );
    await File('${dir.path}/result.json').writeAsString(pretty(result));
    trial.measurement = Measurement.read(result, binary);
    trial.failures.addAll(trial.measurement!.failures);
    if (timedOut) trial.measurement = null;
  } catch (error, stack) {
    trial.failures.add('$error\n$stack');
  }
  duration.stop();
  after ??= await hostLoad();
  await File('${dir.path}/launch.json').writeAsString(
    pretty({
      'id': trial.id,
      'label': options.label,
      'workload': binary.workload,
      'variant': binary.variant,
      'pair': pair,
      'sequence': sequence,
      'executable': binary.executable,
      'archiveIdentity': binary.manifest,
      'launchedUtc': launched,
      'exitedUtc': exited,
      'processElapsedSeconds': duration.elapsedMicroseconds / 1e6,
      'timeoutSeconds': options.timeout.inSeconds,
      'timedOut': timedOut,
      'exitCode': processExit,
      'hostBeforeLaunch': before,
      'hostAfterExit': after,
      'axErrorLines': trial.axErrorLines,
      'diagnosticErrorLines': trial.diagnosticErrorLines,
      'resultRecordCount': trial.resultRecordCount,
      'failureCount': trial.failures.length,
      'failures': trial.failures,
    }),
  );
  return trial;
}

class Measurement {
  Measurement(this.metrics, this.failures, this.start, this.end);
  final Map<String, double> metrics;
  final List<String> failures;
  final Map<String, dynamic> start;
  final Map<String, dynamic> end;

  factory Measurement.read(Map<String, dynamic> data, Binary binary) {
    final failures = <String>[];
    if (data['schemaVersion'] != 1 || data['status'] != 'ok')
      throw FormatException(
        'App reported error or unknown schema: ${data['errors']}',
      );
    if (data['workload'] != binary.workload ||
        data['sourceLabel'] != binary.sourceLabel ||
        data['buildLabel'] != binary.buildLabel) {
      failures.add('Result identity differs from manifest');
    }
    if (data['releaseMode'] != true) failures.add('Not a release build');
    if (array(data, 'errors').isNotEmpty) failures.add('App reported errors');
    if (integer(data, 'errorCount') != 0)
      failures.add('Nonzero app error count');
    if (data['nativeCommitCount'] != null)
      failures.add('Dart cannot count native commits');
    if (data['initialNativeDemand'] != false ||
        array(data, 'nativeDemandTransitions').isNotEmpty)
      failures.add('Native demand was active or changed');
    final start = object(data['start'], 'start');
    final end = object(data['end'], 'end');
    for (final state in [start, end]) {
      if (state['nativeDemand'] != false ||
          state['frameworkSemantics'] != true ||
          state['heldHandle'] != true)
        failures.add('Invalid semantics state');
      if (integer(state, 'attachedNodes') <
          (binary.workload == 'dense' ? 1001 : 2))
        failures.add('Too few attached nodes');
      if (binary.workload == 'dense' &&
          (integer(state, 'denseAttachedNodes') != 1000 ||
              integer(state, 'denseVisibleUnmergedNodes') != 1000))
        failures.add('Dense producer nodes missing');
      final views = array(state, 'views');
      if (views.length != 1)
        throw const FormatException('Expected one benchmark window');
      final view = object(views.single, 'view');
      if (number(view, 'logicalWidth') != 800 ||
          number(view, 'logicalHeight') != 600)
        failures.add('Window content is not 800x600');
      if (number(view, 'devicePixelRatio') <= 0 ||
          (number(view, 'displayRefreshHz') - binary.expectedRefreshHz).abs() >
              0.5 ||
          number(view, 'displayPhysicalWidth') <= 0 ||
          number(view, 'displayPhysicalHeight') <= 0)
        failures.add('Missing display metrics');
      if (integer(view, 'displayId') != 5)
        failures.add('Benchmark window is not on external display 5');
    }
    if (jsonEncode(start['views']) != jsonEncode(end['views']))
      failures.add('Window or display geometry changed');
    final wall = number(data, 'measurementActualSeconds');
    final warmup = number(data, 'warmupActualSeconds');
    final refresh = number(data, 'expectedRefreshHz');
    final completed = integer(data, 'completedFrames');
    final driven = integer(data, 'drivenFrames');
    if ((wall - 20).abs() > 0.5 || warmup < 5)
      failures.add('Duration outside protocol');
    if (refresh != binary.expectedRefreshHz)
      failures.add('Expected refresh differs from manifest');
    final minimum = (wall * refresh * 0.8).ceil();
    if (completed < minimum || driven < minimum)
      failures.add('Fewer than 80% expected refresh frames');
    if ((completed - driven).abs() > math.max(3, (completed * 0.02).ceil()))
      failures.add(
        'Completed/driven count differs beyond 2% or 3 boundary frames',
      );
    if ((integer(data, 'producerTickerFrames') - driven).abs() > 1)
      failures.add('Producer/driven count differs beyond one boundary frame');
    if (binary.workload == 'dense') {
      final builds = integer(data, 'denseBuildBatches');
      if ((builds - driven).abs() > math.max(3, (driven * 0.02).ceil()) ||
          (integer(data, 'denseLabelChangeBatches') - builds).abs() > 1 ||
          integer(data, 'denseLabelAssignments') != builds * 1000) {
        failures.add('Dense work counters differ beyond boundary allowance');
      }
    } else if (integer(data, 'reproBannerToggles') < 12) {
      failures.add('Too few reproduction banner toggles');
    }
    final begin = integer(data, 'measurementStartMonotonicMicros');
    final finish = integer(data, 'measurementEndMonotonicMicros');
    if (((finish - begin) / 1e6 - wall).abs() > 0.000001)
      failures.add('Inconsistent wall duration');
    final cpu = number(data, 'cpuSeconds');
    if (cpu <= 0 ||
        (cpu -
                    (integer(data, 'cpuEndNanoseconds') -
                            integer(data, 'cpuStartNanoseconds')) /
                        1e9)
                .abs() >
            1e-9)
      failures.add('Invalid process CPU interval');
    final cpuPercent = number(data, 'cpuPercentOneCore');
    final cpuPerFrame = number(data, 'cpuMsPerCompletedFrame');
    if ((cpuPercent - cpu / wall * 100).abs() > 1e-6 ||
        (cpuPerFrame - cpu * 1000 / completed).abs() > 1e-6)
      failures.add('Invalid CPU normalization');
    if ((number(data, 'completedFps') - completed / wall).abs() > 1e-6)
      failures.add('Invalid FPS');
    final samples = array(data, 'memorySamples');
    if (integer(data, 'memorySampleIntervalMs') != 250 || samples.length < 78)
      failures.add('Too few 250ms memory samples');
    for (final sample in samples) {
      final memory = object(sample, 'memory sample');
      final time = integer(memory, 'monotonicMicros');
      if (time < begin || time > finish)
        failures.add('Memory sample outside timed interval');
      if (integer(memory, 'rssBytes') <= 0 ||
          integer(memory, 'physicalFootprintBytes') <= 0)
        failures.add('Invalid memory sample');
    }
    final timing = object(data['timingWindow'], 'timingWindow');
    if (integer(timing, 'firstBuildStartMicros') < begin ||
        integer(timing, 'lastRasterFinishMicros') > finish ||
        integer(timing, 'lastDeliveredRasterFinishMicros') < finish)
      failures.add('Invalid FrameTiming window or incomplete drain');
    final rss = object(data['rssBytes'], 'rssBytes');
    final footprint = object(
      data['physicalFootprintBytes'],
      'physicalFootprintBytes',
    );
    final build = object(data['buildMicros'], 'buildMicros');
    final raster = object(data['rasterMicros'], 'rasterMicros');
    if (integer(build, 'count') != completed ||
        integer(raster, 'count') != completed)
      failures.add('FrameTiming counts differ');
    if (integer(rss, 'count') != samples.length ||
        integer(footprint, 'count') != samples.length)
      failures.add('Memory counts differ');
    final frames = array(data, 'frameSamples');
    final frameNumbers = <int>{};
    for (final value in frames) {
      final frame = object(value, 'frame sample');
      if (!frameNumbers.add(integer(frame, 'frameNumber')) ||
          integer(frame, 'buildStartMicros') < begin ||
          integer(frame, 'rasterFinishMicros') > finish ||
          integer(frame, 'buildMicros') < 0 ||
          integer(frame, 'rasterMicros') < 0) {
        failures.add('Invalid or duplicate raw frame sample');
      }
    }
    if (frames.length != completed)
      failures.add('Raw frame sample count differs');
    return Measurement(
      {
        'cpuPercentOneCore': cpuPercent,
        'cpuSeconds': cpu,
        'cpuMsPerCompletedFrame': cpuPerFrame,
        'measurementActualSeconds': wall,
        'rssMedianBytes': number(rss, 'p50'),
        'rssMinBytes': number(rss, 'min'),
        'rssMaxBytes': number(rss, 'max'),
        'rssMedianMiB': number(rss, 'p50') / (1024 * 1024),
        'rssMinMiB': number(rss, 'min') / (1024 * 1024),
        'rssMaxMiB': number(rss, 'max') / (1024 * 1024),
        'physicalFootprintMedianBytes': number(footprint, 'p50'),
        'physicalFootprintMinBytes': number(footprint, 'min'),
        'physicalFootprintMaxBytes': number(footprint, 'max'),
        'physicalFootprintMedianMiB': number(footprint, 'p50') / (1024 * 1024),
        'physicalFootprintMinMiB': number(footprint, 'min') / (1024 * 1024),
        'physicalFootprintMaxMiB': number(footprint, 'max') / (1024 * 1024),
        'processLifetimeMaxRssBytes': number(
          data,
          'processLifetimeMaxRssBytes',
        ),
        'completedFps': number(data, 'completedFps'),
        'completedFrames': completed.toDouble(),
        'drivenFrames': driven.toDouble(),
        'producerTickerFrames': number(data, 'producerTickerFrames'),
        'denseBuildBatches': number(data, 'denseBuildBatches'),
        'denseLabelChangeBatches': number(data, 'denseLabelChangeBatches'),
        'denseLabelAssignments': number(data, 'denseLabelAssignments'),
        'reproBannerToggles': number(data, 'reproBannerToggles'),
        'buildP50Micros': number(build, 'p50'),
        'buildP95Micros': number(build, 'p95'),
        'rasterP50Micros': number(raster, 'p50'),
        'rasterP95Micros': number(raster, 'p95'),
        'attachedNodesStart': number(start, 'attachedNodes'),
        'attachedNodesEnd': number(end, 'attachedNodes'),
      },
      failures,
      start,
      end,
    );
  }
}

Map<String, Object?> summarize(List<Trial> trials) {
  final groups = <String, Map<String, Map<String, double>>>{};
  for (final variant in ['a', 'b']) {
    final valid = trials
        .where((t) => t.binary.variant == variant && t.failures.isEmpty)
        .map((t) => t.measurement!)
        .toList();
    groups[variant] = valid.isEmpty
        ? {}
        : {
            for (final key in valid.first.metrics.keys)
              key: stats(valid.map((m) => m.metrics[key]!).toList()),
          };
  }
  final failed = trials.where((t) => t.failures.isNotEmpty).length;
  if (failed != 0 || trials.length != 10)
    return {
      'status': 'ERROR',
      'failedTrials': failed,
      'variants': groups,
      'comparison': null,
      'verdict': 'inconclusive; failed or missing trials',
    };
  final a = groups['a']!;
  final b = groups['b']!;
  final allViews = trials
      .expand(
        (t) => [t.measurement!.start['views'], t.measurement!.end['views']],
      )
      .map(jsonEncode)
      .toSet();
  if (allViews.length != 1)
    return {
      'status': 'ERROR',
      'variants': groups,
      'comparison': null,
      'verdict':
          'inconclusive; display or window geometry differs across trials',
    };
  Map<String, Object> difference(String metric, double divisor, String unit) {
    final baseline = a[metric]!;
    final patch = b[metric]!;
    final delta = (patch['median']! - baseline['median']!) / divisor;
    final variation =
        math.max(
          baseline['max']! - baseline['min']!,
          patch['max']! - patch['min']!,
        ) /
        divisor;
    final overlap =
        baseline['min']! <= patch['max']! && patch['min']! <= baseline['max']!;
    return {
      'bMinusA': delta,
      'unit': unit,
      'maximumWithinVariantRange': variation,
      'rangesOverlap': overlap,
      'assessment': delta.abs() <= variation || overlap
          ? 'no measurable difference above observed variability'
          : 'numerically separated; inconclusive until parent supplies limiter profile and work-equivalence review',
    };
  }

  return {
    'status': 'complete',
    'variants': groups,
    'trialsPerVariant': 5,
    'cpuDeltaPercentagePoints': difference(
      'cpuPercentOneCore',
      1,
      'percentage points of one core',
    ),
    'rssDeltaMiB': difference('rssMedianBytes', 1024 * 1024, 'MiB'),
    'physicalFootprintDeltaMiB': difference(
      'physicalFootprintMedianBytes',
      1024 * 1024,
      'MiB',
    ),
    'cpuMsPerCompletedFrameDelta': difference(
      'cpuMsPerCompletedFrame',
      1,
      'ms/completed frame',
    ),
    'completedFpsDelta': difference(
      'completedFps',
      1,
      'completed frames/second',
    ),
    'verdict': 'inconclusive until parent provides separate limiter and native-commit profiling; review work counts beside CPU',
  };
}

Future<Map<String, Object?>> hostLoad() async {
  final result = await Process.run(
    '/usr/bin/uptime',
    const [],
    environment: {'LC_ALL': 'C'},
  );
  if (result.exitCode != 0) throw StateError('uptime failed: ${result.stderr}');
  final raw = result.stdout as String;
  final match = RegExp(
    r'load averages?:\s*([0-9.]+)[, ]+([0-9.]+)[, ]+([0-9.]+)',
  ).firstMatch(raw);
  if (match == null)
    throw FormatException('Could not parse uptime host load: $raw');
  return {
    'capturedUtc': DateTime.now().toUtc().toIso8601String(),
    'source': '/usr/bin/uptime',
    'raw': raw,
    'load1': double.parse(match.group(1)!),
    'load5': double.parse(match.group(2)!),
    'load15': double.parse(match.group(3)!),
    'logicalProcessors': Platform.numberOfProcessors,
  };
}

Map<String, double> stats(List<double> values) {
  values.sort();
  final middle = values.length ~/ 2;
  return {
    'count': values.length.toDouble(),
    'median': values.length.isOdd
        ? values[middle]
        : (values[middle - 1] + values[middle]) / 2,
    'min': values.first,
    'max': values.last,
  };
}

Map<String, dynamic> object(Object? value, String name) {
  if (value is! Map<String, dynamic>)
    throw FormatException('$name must be an object');
  return value;
}

List<dynamic> array(Map<String, dynamic> value, String key) {
  final field = value[key];
  if (field is! List<dynamic>) throw FormatException('$key must be an array');
  return field;
}

String string(Map<String, dynamic> value, String key) {
  final field = value[key];
  if (field is! String || field.isEmpty)
    throw FormatException('$key must be a nonempty string');
  return field;
}

double number(Map<String, dynamic> value, String key) {
  final field = value[key];
  if (field is! num || !field.isFinite)
    throw FormatException('$key must be finite');
  return field.toDouble();
}

int integer(Map<String, dynamic> value, String key) {
  final field = value[key];
  if (field is! int) throw FormatException('$key must be an integer');
  return field;
}

String pretty(Object? value) =>
    '${const JsonEncoder.withIndent('  ').convert(value)}\n';
