import Cocoa
import FlutterMacOS

class MainFlutterWindow: NSWindow {
  override func awakeFromNib() {
    let flutterViewController = FlutterViewController()
    self.contentViewController = flutterViewController
    self.setContentSize(NSSize(width: 800, height: 600))
    self.styleMask.remove(.resizable)
    self.isMovable = false
    guard let screen = NSScreen.screens.first(where: {
      ($0.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.intValue == 5
    }) else {
      fatalError("Benchmark display 5 is unavailable")
    }
    self.setFrameOrigin(NSPoint(
      x: screen.visibleFrame.midX - self.frame.width / 2,
      y: screen.visibleFrame.midY - self.frame.height / 2
    ))

    RegisterGeneratedPlugins(registry: flutterViewController)

    super.awakeFromNib()
  }
}
